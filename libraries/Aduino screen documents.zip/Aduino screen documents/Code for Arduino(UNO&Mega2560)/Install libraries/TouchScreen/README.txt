This is the 4-wire resistive touch screen firmware for Arduino. Works with all Arduinos and the Mega


To install, click DOWNLOAD SOURCE in the top right corner, and rename the uncompressed folder "TouchScreen". See our tutorial at http://www.ladyada.net/library/arduino/libraries.html on Arduino Library installation